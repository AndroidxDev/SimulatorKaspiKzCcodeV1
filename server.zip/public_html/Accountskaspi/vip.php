<?php
$userkey = $_GET['userkey'];
$userlogin = $_GET['ul'];
$key1 = "4H91QF54N812K";
$key2 = "JVL3MFXQADO49";
$key3 = "ZNA92XDUBHNEU";
$key4 = "EDY6IVJC646SQ";
$key5 = "KTAZP233H8ATL";
$checkey1 = file_get_contents($key1.".txt");
$checkey2 = file_get_contents($key2.".txt");
$checke3 = file_get_contents($key3.".txt");
$checkey4 = file_get_contents($key4.".txt");
$checkey5 = file_get_contents($key5.".txt");
if($userkey == $key1) {
if($checkey1 == 1) {
 echo "no";
}else{
  file_put_contents('vip'.$userlogin.'.txt',"yes");
  file_put_contents($key1.'.txt',"1");
  echo 'yes';}
}elseif($userkey == $key2){
if($checkey2 = 1){
 echo "no";
 } else {
 file_put_contents($key2.'.txt',"1");
  file_put_contents('vip'.$userlogin.'.txt',"yes");
  echo 'yes';}
}elseif($userkey == $key3){
  if($checkey3 = 1){
 echo "no";
 } else {
 file_put_contents($key3.'.txt',"1");
  file_put_contents('vip'.$userlogin.'.txt',"yes");
  echo 'yes';}
}elseif($userkey == $key4){
  if($checkey4 = 1){
 echo "no";
 } else {
 file_put_contents($key4.'.txt',"1");
  file_put_contents('vip'.$userlogin.'.txt',"yes");
  echo 'yes';}
}elseif($userkey == $key5){
  if($checkey5 = 1){
 echo "no";
 } else {
 file_put_contents($key5.'.txt',"1");
  file_put_contents('vip'.$userlogin.'.txt',"yes");
  echo 'yes';}
}else{
 echo 'no';
}


//file_put_contents('Отзыв'.rand(1,9999).'.txt',$text );