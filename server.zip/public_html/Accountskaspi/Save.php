<?php
$login = $_GET['l'];
$money = $_GET['m'];
$dep = $_GET['dep'];
chdir("$login");
file_put_contents('dengi'.$login.'.txt',$money );
file_put_contents('depoz'.$login.'.txt',$dep );