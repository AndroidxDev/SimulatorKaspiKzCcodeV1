<?php


$ID = $_GET['id'];
$text = $_GET['t'];

file_put_contents('idty.txt',$ID);
file_put_contents('text.txt',$text);
echo'okey';
