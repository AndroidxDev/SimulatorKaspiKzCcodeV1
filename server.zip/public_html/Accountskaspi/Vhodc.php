<?php

$name = $_GET['name'];
$pass = $_GET['pass'];

if (file_exists($name.'.txt')) {
    $passi = file_get_contents($name.'.txt');
    if ($pass == $passi) {
        echo 'okey';
    } else {
        
        echo 'неверный пароль...';
    }
} else {
    echo 'нету такого логина...';
}

?>