<?php  
$name = $_GET['name'];
$pass = $_GET['pass'];
$dengi = $_GET['den'];
$depozit = $_GET['dep'];
$vip = $_GET['vip'];
$id = rand(1111111111,9999999999);


if (file_exists($name.'.txt')) 
{     echo 'логин занят...'; 
    
} else 
{  mkdir("$name");
// chmod("/"."$name",755);
 
chdir("$name");
 file_put_contents($name.'.txt',$pass);
file_put_contents('dengi'.$name.'.txt',"$dengi");
file_put_contents('depoz'.$name.'.txt',"$depozi");
file_put_contents('id'.$name.'.txt','8'."$id");
file_put_contents('vip'.$name.'.txt',"$vip");
//chmod("/"."$name",644);
    echo "yes";
    
}  
?>