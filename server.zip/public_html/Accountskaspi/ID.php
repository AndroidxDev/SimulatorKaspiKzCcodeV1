<?php


$ID = $_GET['id'];

file_put_contents('idty.txt',$ID);

echo'okey';
