<?php

$name = $_GET['name'];
$pass = $_GET['pass'];
chdir("$name");
if (file_exists($name.'.txt')) {
//chdir("$name");
    $passi = file_get_contents($name.'.txt');
    if ($pass == $passi) {
        echo 'okey';
    } else {
        
        echo 'неверный пароль...';
    }
} else {
    echo 'нету такого логина...';
}

?>