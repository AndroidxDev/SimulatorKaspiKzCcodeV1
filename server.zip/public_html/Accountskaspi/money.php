<?php

$gn = $_GET['gn'];

    file_put_contents('gengity.txt',$gn);
   // 
  echo 'okey';


?>