<?php
$text = $_GET['text'];
//$money = $_GET['m'];
file_put_contents('Отзыв'.rand(1,9999).'.txt',$text );